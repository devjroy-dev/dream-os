#!/usr/bin/env bash
# Phase 2.5 apply — enquiry smoothing + budget neutral fact + Invoices copy fix
# Backend only (dream-os). Run from the dream-os repo root.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date +%Y%m%d_%H%M%S)"
FILES=("src/lib/vendor/enquiryEnrichment.js" "src/agent/pwaSystemPrompt.js")

echo "──────────────────────────────────────────────"
echo " DreamAi — Phase 2.5 apply"
echo "──────────────────────────────────────────────"

if [[ ! -d "src/agent" || ! -f "src/index.js" ]]; then
  echo "✗ Not in dream-os root. Run from /workspaces/dream-os."; exit 1
fi
echo "✓ In dream-os root."

BACKUP_DIR=".phase2_5_backup/$TS"
mkdir -p "$BACKUP_DIR/src/lib/vendor" "$BACKUP_DIR/src/agent"
for f in "${FILES[@]}"; do [[ -f "$f" ]] && cp "$f" "$BACKUP_DIR/$f"; done
echo "✓ Backed up to $BACKUP_DIR/"

for f in "${FILES[@]}"; do
  cp "$SCRIPT_DIR/files/$f" "$f"
  echo "  → $f"
done

echo "── Syntax checks ──"
FAIL=0
for f in "${FILES[@]}"; do
  node --check "$f" 2>/dev/null && echo "  ✓ $f" || { echo "  ✗ $f SYNTAX ERROR"; FAIL=1; }
done

if [[ "$FAIL" != "0" ]]; then
  echo "✗ Restoring."; for f in "${FILES[@]}"; do [[ -f "$BACKUP_DIR/$f" ]] && cp "$BACKUP_DIR/$f" "$f"; done; exit 1
fi

echo "✓ Phase 2.5 applied."
echo ""
echo "  Now make it live:"
echo "    git add src/ && git commit -m 'Phase 2.5: budget neutral fact + Invoices copy fix' && git push origin main"
